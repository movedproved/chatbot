const TelegramBot = require('node-telegram-bot-api');
const Q = require('q');
const xml2js = require('xml2js');
const request = Q.denodeify(require("request"));

// replace the value below with the Telegram token you receive from @BotFather
const token = '348322024:AAElZ3phHEXR2XlrfEuiyis-gFCwLwkU7es';

// Create a bot that uses 'polling' to fetch new updates
const bot = new TelegramBot(token, {polling: true});




// Matches "/echo [whatever]"
bot.onText(/\/echo (.+)/, (msg, match) => {
  // 'msg' is the received Message from Telegram
  // 'match' is the result of executing the regexp above on the text content
  // of the message

  const chatId = msg.chat.id;
  const resp = match[1]; // the captured "whatever"

  // send back the matched "whatever" to the chat
  bot.sendMessage(chatId, resp);
});

// RU SOLO

bot.onText(/\/solo/, (msg, match) => {
  // 'msg' is the received Message from Telegram
  // 'match' is the result of executing the regexp above on the text content
  // of the message

  const chatId = msg.chat.id;
  const solo = ["20gg","thich thi chieu", "chiennnnn"];
  const resp = solo[Math.floor(Math.random() * solo.length)];

  // send back the matched "whatever" to the chat
  bot.sendMessage(chatId, resp);
});




//HELP

bot.onText(/\/help/, (msg, match) => {
  // 'msg' is the received Message from Telegram
  // 'match' is the result of executing the regexp above on the text content
  // of the message

  const chatId = msg.chat.id;
  

  // send back the matched "whatever" to the chat
  bot.sendMessage(chatId, " here is the list of command:");
  bot.sendMessage(chatId, " /echo [whatever] test message ");
  bot.sendMessage(chatId, " /solo testing random");
  bot.sendMessage(chatId, " /chat [hi, okuni] chat voi bot");
  bot.sendMessage(chatId, " /pic [dog, cat] show random pic");
  bot.sendMessage(chatId, " /file send an expample pdf");
  bot.sendMessage(chatId, " /video send example video ( mp4)");
  bot.sendMessage(chatId, " /voice send example voice ( ogg)");
  bot.sendMessage(chatId, " /love keyboard input example");
  bot.sendMessage(chatId, " /audio [tung, soobin] play some music ( mp3)");
  bot.sendMessage(chatId, " /weather [94107] testing API");
});

bot.onText(/\/file/, (msg,match) => {
  const chatId = msg.chat.id;
  bot.sendDocument (chatId, "https://www.opennetworking.org/images/stories/downloads/sdn-resources/white-papers/wp-sdn-newnorm.pdf");
});

bot.onText(/\/video/, (msg,match) => {
  const chatId = msg.chat.id;
  bot.sendVideo (chatId, "http://techslides.com/demos/sample-videos/small.mp4");
});

bot.onText(/\/voice/, (msg,match) => {
  const chatId = msg.chat.id;
  bot.sendVoice (chatId, "https://upload.wikimedia.org/wikipedia/en/4/45/ACDC_-_Back_In_Black-sample.ogg");
});

bot.onText(/\/game/, (msg,match) => {
  const chatId = msg.chat.id;
  bot.sendGame (chatId, "tetris");
});

// Matches /love
bot.onText(/\/love/, function onLoveText(msg) {
  const opts = {
    reply_to_message_id: msg.message_id,
    reply_markup: JSON.stringify({
      keyboard: [
        ['Yes, you are the bot of my life ❤'],
        ['No, sorry there is another one...']
      ]
    })
  };
  bot.sendMessage(msg.chat.id, 'Do you love me?', opts);
});


// Listen for any kind of message. There are different kinds of
// messages.
bot.on('message', (msg) => {
  const chat = msg.text;
  const chatId = msg.chat.id;
  
  if ( chat === 'hi' )
  {

  // send a message to the chat acknowledging receipt of their message
  bot.sendMessage(chatId, 'nani sore');
  }
  
  if ( chat === 'okuni' )
  {

  // send a message to the chat acknowledging receipt of their message
  bot.sendMessage(chatId, 'betonamu');
  }
  
  else{
    //const replay = ["wakarimasen", "shiranai", "muzukashi desu"];
    //const choicereplay = replay[Math.floor(Math.random() * replay.legth)];
    bot.sendMessage(chatId, ' message received' );
  }
});

bot.onText(/\/echo (.+)/, (msg, match) => {
  // 'msg' is the received Message from Telegram
  // 'match' is the result of executing the regexp above on the text content
  // of the message

  const chatId = msg.chat.id;
  const resp = match[1]; // the captured "whatever"

  // send back the matched "whatever" to the chat
  bot.sendMessage(chatId, resp);
});

bot.onText(/\/pic (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const resp = match[1];
  const catPic = ["https://i.ytimg.com/vi/tntOCGkgt98/maxresdefault.jpg","https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcT5b0A1z6Z2B_NjiSXN09Mje9hT54rorwnS-BwlkQe13tB1NpyuFg", "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRhKLJBGZa3B6J9HoQ04GAWZSp452Vun8wHlTup4126RifmIM-f"];
  const randomCat = catPic[Math.floor(Math.random() * catPic.length)];
  const dogPic = ["https://pbs.twimg.com/profile_images/815952963441201152/Yt6qufUi.jpg", "https://www.rover.com/blog/wp-content/uploads/2015/05/dog-candy-junk-food-599x340.jpg"];
  const randomDog = dogPic[Math.floor(Math.random() * dogPic.length)];
  if (( resp === 'cat') || (resp === "dog"))
  {
    if ( resp === 'cat')
    {
      bot.sendPhoto(chatId, randomCat);
    }
    if ( resp === 'dog')
    {
      bot.sendPhoto(chatId, randomDog);
    }}
  
  else
  {
    bot.sendMessage(chatId, "No data, send random pic");
    bot.sendPhoto(chatId,'http://sd.keepcalm-o-matic.co.uk/i/keep-calm-and-be-random-437.png');
  }

});

bot.onText(/\/audio (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const resp = match[1];
  const tung = [""];
  bot.sendMessage(chatId, "First time it's will take time to download, please patient ");
  if ( resp === "tung")
  {
    bot.sendAudio(chatId, "http://zmp3-mp3-s1.zmp3-bdhcm-2.za.zdn.vn/d41230d1df9536cb6f84/1181817601640857205?key=W7S5CT7AcfNo-VTl2CAGdQ&expires=1488364448");
  }
  if ( resp === "soobin")
  {
    bot.sendAudio(chatId, "http://zmp3-mp3-s1.zmp3-bdhcm-2.za.zdn.vn/a32e305cab1842461b09/4870257449214198184?key=oZSFGBW1fFk4WoyyPrxW1Q&expires=1488363662");
  }
  bot.sendChatAction (chatId, "upload_audio");
});




// match /weather [whatever]
bot.onText(/\/weather (.+)/, function (msg, match) {
  var fromId = msg.from.id; // get the id, of who is sending the message
  var postcode = match[1];
  getWeatherData(postcode)
  .then(function(data){
    var message = "Weather today in "+postcode+"\n";
    message += data.wx_desc+"\n";
    message += "temp: "+data.temp_c+"C or "+data.temp_f+"F";
    bot.sendMessage(fromId, message);
  });

});

function getWeatherData(postcode){
  var app_id = "b202fa7b";
  var app_key = "4aa2456cc39c7065a786a60d64f285e2";
  var url = "http://api.weatherunlocked.com/api/current/us."+postcode;
  url += "?app_id="+app_id+"&app_key="+app_key;

  var options ={
      url: url,
      method: "GET",
      json:true,
    };
    var response = request(options);
    return response.then(function (r){
        return r[0].body;
    });
}